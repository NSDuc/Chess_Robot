function path = voc0712_devkit()
    path = './datasets/VOCdevkit0712';
end
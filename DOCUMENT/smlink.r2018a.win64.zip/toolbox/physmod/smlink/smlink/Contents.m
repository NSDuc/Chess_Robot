% Simscape Multibody Link
% Version 5.2 (R2018a) 19-Jan-2018

%   Copyright 2007-2018 The MathWorks, Inc.
